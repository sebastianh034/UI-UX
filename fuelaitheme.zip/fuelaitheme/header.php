<?php
/**
 * The header for our theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header -->
<header>
    <div class="container">
        <nav>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                <div class="logo-container">
                    <?php
                    // Check if custom logo is set
                    if (has_custom_logo()) {
                        the_custom_logo();
                    } else {
                    ?>
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/fuel-button-white.png" alt="<?php bloginfo('name'); ?> logo icon" class="logo-icon">
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/fuel.AI.png" alt="<?php bloginfo('name'); ?> text logo" class="logo-text-image">
                    <?php } ?>
                </div>
            </a>
            
            <?php
            // Display the primary menu
            wp_nav_menu(array(
                'theme_location' => 'header-menu',
                'menu_class'     => 'nav-links',
                'container'      => '',
                'fallback_cb'    => false,
            ));
            ?>
        </nav>
    </div>
</header>