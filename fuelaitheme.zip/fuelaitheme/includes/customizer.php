<?php
/**
 * Fuel AI Theme Customizer
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function fuel_customize_register($wp_customize) {
    // Add a new section for homepage hero settings
    $wp_customize->add_section('fuel_hero_section', array(
        'title'    => __('Homepage Hero', 'fuel-ai'),
        'priority' => 30,
    ));

    // Hero Title
    $wp_customize->add_setting('fuel_hero_title', array(
        'default'           => 'FUEL YOUR SALES WITH AI',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_hero_title', array(
        'label'    => __('Hero Title', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'text',
    ));

    // Hero Heading
    $wp_customize->add_setting('fuel_hero_heading', array(
        'default'           => 'BOOK MORE MEETINGS AND CLOSE MORE DEALS. AUTOMATICALLY.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_hero_heading', array(
        'label'    => __('Hero Heading', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'text',
    ));

    // Hero Description
    $wp_customize->add_setting('fuel_hero_description', array(
        'default'           => 'AI-powered follow-up and scheduling that converts leads into appointments — so your sales team can focus on selling, not chasing.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_hero_description', array(
        'label'    => __('Hero Description', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'textarea',
    ));

    // CTA Button text
    $wp_customize->add_setting('fuel_cta_button_text', array(
        'default'           => 'BOOK A DEMO TODAY',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_cta_button_text', array(
        'label'    => __('CTA Button Text', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'text',
    ));

    // CTA Button link
    $wp_customize->add_setting('fuel_cta_button_link', array(
        'default'           => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('fuel_cta_button_link', array(
        'label'    => __('CTA Button Link', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'url',
    ));

    // Hero YouTube Video URL
    $wp_customize->add_setting('fuel_hero_video_url', array(
        'default'           => 'https://www.youtube.com/embed/TmUJoSnpd00',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('fuel_hero_video_url', array(
        'label'    => __('YouTube Video URL (embed link)', 'fuel-ai'),
        'section'  => 'fuel_hero_section',
        'type'     => 'url',
    ));

    // Add a new section for features
    $wp_customize->add_section('fuel_features_section', array(
        'title'    => __('Homepage Features', 'fuel-ai'),
        'priority' => 35,
    ));

    // Feature 1
    $wp_customize->add_setting('fuel_feature1_title', array(
        'default'           => 'FOLLOW-UP MADE EASY',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature1_title', array(
        'label'    => __('Feature 1 Title', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_feature1_description', array(
        'default'           => 'Every lead gets the attention they deserve with perfectly timed, personalized outreach across multiple channels.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature1_description', array(
        'label'    => __('Feature 1 Description', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'textarea',
    ));

    // Feature 2
    $wp_customize->add_setting('fuel_feature2_title', array(
        'default'           => 'MORE MEETINGS, LESS HASSLE',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature2_title', array(
        'label'    => __('Feature 2 Title', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_feature2_description', array(
        'default'           => 'fuel.AI boosts lead response rates by automatically sending reminders, managing reminders, and rescheduling when needed.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature2_description', array(
        'label'    => __('Feature 2 Description', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'textarea',
    ));

    // Feature 3
    $wp_customize->add_setting('fuel_feature3_title', array(
        'default'           => 'SCALE WITHOUT LIMITS',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature3_title', array(
        'label'    => __('Feature 3 Title', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_feature3_description', array(
        'default'           => 'Grow your business without hiring and administrative overhead, making fuel.AI the ultimate solution for scalable sales automation.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_feature3_description', array(
        'label'    => __('Feature 3 Description', 'fuel-ai'),
        'section'  => 'fuel_features_section',
        'type'     => 'textarea',
    ));

    // Add a new section for stats
    $wp_customize->add_section('fuel_stats_section', array(
        'title'    => __('Stats Section', 'fuel-ai'),
        'priority' => 40,
    ));

    // Stats Title
    $wp_customize->add_setting('fuel_stats_title', array(
        'default'           => 'WHY US?',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stats_title', array(
        'label'    => __('Stats Section Title', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    // Stats Image
    $wp_customize->add_setting('fuel_stats_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'fuel_stats_image', array(
        'label'    => __('Statistics Graph Image', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'settings' => 'fuel_stats_image',
    )));

    // Statistic 1
    $wp_customize->add_setting('fuel_stat1_number', array(
        'default'           => '70%',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat1_number', array(
        'label'    => __('Statistic 1 Number', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_stat1_description', array(
        'default'           => 'Of businesses take over 24 hrs to respond to leads',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat1_description', array(
        'label'    => __('Statistic 1 Description', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    // Statistic 2
    $wp_customize->add_setting('fuel_stat2_number', array(
        'default'           => '80%',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat2_number', array(
        'label'    => __('Statistic 2 Number', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_stat2_description', array(
        'default'           => 'Of deals go with the vendor that responds first',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat2_description', array(
        'label'    => __('Statistic 2 Description', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    // Statistic 3
    $wp_customize->add_setting('fuel_stat3_number', array(
        'default'           => '92%',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat3_number', array(
        'label'    => __('Statistic 3 Number', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    $wp_customize->add_setting('fuel_stat3_description', array(
        'default'           => 'Of sales reps only follow-up up to 4 times',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_stat3_description', array(
        'label'    => __('Statistic 3 Description', 'fuel-ai'),
        'section'  => 'fuel_stats_section',
        'type'     => 'text',
    ));

    // Add a section for contact info in the footer
    $wp_customize->add_section('fuel_contact_section', array(
        'title'    => __('Contact Information', 'fuel-ai'),
        'priority' => 100,
    ));

    // Phone Number
    $wp_customize->add_setting('fuel_phone_number', array(
        'default'           => '(435) 375-3509',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_phone_number', array(
        'label'    => __('Phone Number', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'text',
    ));

    // Email Address
    $wp_customize->add_setting('fuel_email_address', array(
        'default'           => 'EXAMPLEEMAIL@GMAIL.COM',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('fuel_email_address', array(
        'label'    => __('Email Address', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'email',
    ));

    // Address Line 1
    $wp_customize->add_setting('fuel_address_line1', array(
        'default'           => '85 N 300 W #C',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_address_line1', array(
        'label'    => __('Address Line 1', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'text',
    ));

    // Address Line 2
    $wp_customize->add_setting('fuel_address_line2', array(
        'default'           => 'WASHINGTON UTAH',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_address_line2', array(
        'label'    => __('Address Line 2', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'text',
    ));

    // Address Line 3
    $wp_customize->add_setting('fuel_address_line3', array(
        'default'           => '84790',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('fuel_address_line3', array(
        'label'    => __('Address Line 3 (Zip)', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'text',
    ));

    // Social Media Links
    $wp_customize->add_setting('fuel_facebook_url', array(
        'default'           => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('fuel_facebook_url', array(
        'label'    => __('Facebook URL', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'url',
    ));

    $wp_customize->add_setting('fuel_youtube_url', array(
        'default'           => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('fuel_youtube_url', array(
        'label'    => __('YouTube URL', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'url',
    ));

    $wp_customize->add_setting('fuel_linkedin_url', array(
        'default'           => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('fuel_linkedin_url', array(
        'label'    => __('LinkedIn URL', 'fuel-ai'),
        'section'  => 'fuel_contact_section',
        'type'     => 'url',
    ));
    
    // Add more customization options for other sections as needed
}
add_action('customize_register', 'fuel_customize_register');