<?php
/**
 * Custom Walker for Footer Navigation
 */

class Fuel_Footer_Nav_Walker extends Walker_Nav_Menu {
    /**
     * Start the element output.
     */
    public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $output .= '<a href="' . esc_url($item->url) . '" class="footer-nav-link"' . $class_names . '>';
        $output .= apply_filters('the_title', $item->title, $item->ID);
        $output .= '</a>';
    }
    
    /**
     * Ends the element output.
     */
    public function end_el(&$output, $item, $depth = 0, $args = array()) {
        $output .= "";
    }
    
    /**
     * Start the list wrapper.
     */
    public function start_lvl(&$output, $depth = 0, $args = array()) {
        $output .= "";
    }
    
    /**
     * End the list wrapper.
     */
    public function end_lvl(&$output, $depth = 0, $args = array()) {
        $output .= "";
    }
}