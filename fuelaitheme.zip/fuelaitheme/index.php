<?php
/**
 * The main template file
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <?php
        if (have_posts()) :
            while (have_posts()) :
                the_post();
                ?>
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
                <?php
            endwhile;
            
            // Pagination
            the_posts_navigation();
        else :
            ?>
            <h1 class="entry-title"><?php esc_html_e('Nothing Found', 'fuel-ai'); ?></h1>
            <div class="entry-content">
                <p><?php esc_html_e('It seems we cannot find what you are looking for.', 'fuel-ai'); ?></p>
            </div>
            <?php
        endif;
        ?>
    </div>
</main>

<?php
get_footer();