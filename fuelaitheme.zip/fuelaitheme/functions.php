<?php
/**
 * Fuel AI Theme functions and definitions
 */

// Set up theme support
function fuel_theme_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');

    // Switch default core markup to output valid HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));

    // Add support for core custom logo
    add_theme_support('custom-logo');

    // Add support for Block Editor features
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'fuel_theme_setup');

// Register custom navigation menus
function fuel_register_menus() {
    register_nav_menus(array(
        'header-menu' => __('Header Menu', 'fuel-ai'),
        'footer-menu' => __('Footer Menu', 'fuel-ai'),
    ));
}
add_action('init', 'fuel_register_menus');

// Register widget areas
function fuel_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'fuel-ai'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'fuel-ai'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'fuel_widgets_init');

// Enqueue scripts and styles
function fuel_scripts() {
    // Enqueue the main stylesheet
    wp_enqueue_style('fuel-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue Google Fonts
    wp_enqueue_style('lato-font', 'https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap', array(), null);
    
    // Enqueue JavaScript for testimonial slider
    wp_enqueue_script('fuel-testimonials', get_template_directory_uri() . '/js/testimonials.js', array(), '1.0.0', true);

    // Add comment reply script if needed
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'fuel_scripts');

// Custom template tags for this theme
function fuel_posted_on() {
    $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
    if (get_the_time('U') !== get_the_modified_time('U')) {
        $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
    }

    $time_string = sprintf($time_string,
        esc_attr(get_the_date('c')),
        esc_html(get_the_date()),
        esc_attr(get_the_modified_date('c')),
        esc_html(get_the_modified_date())
    );

    echo '<span class="posted-on">' . $time_string . '</span>';
}

// Add customizer settings - include the customizer.php file
require get_template_directory() . '/includes/customizer.php';

// Load custom walker for footer menu (if file exists)
if (file_exists(get_template_directory() . '/includes/class-fuel-footer-nav-walker.php')) {
    require get_template_directory() . '/includes/class-fuel-footer-nav-walker.php';
}

// Add testimonial data to JS
function fuel_testimonials_script() {
    $testimonials = fuel_get_testimonials_data();
    
    // Pass testimonial data to JS
    wp_localize_script('fuel-testimonials', 'fuelTestimonials', $testimonials);
    
    // Pass theme URL to JS for image path resolution
    wp_localize_script('fuel-testimonials', 'fuelThemeVars', array(
        'templateUrl' => get_template_directory_uri(),
    ));
}
add_action('wp_enqueue_scripts', 'fuel_testimonials_script', 20);

// Convert testimonials to data array for JS
function fuel_get_testimonials_data() {
    $testimonials = array();
    
    // Get testimonials from custom post type if it exists
    $testimonial_posts = get_posts(array(
        'post_type' => 'testimonial',
        'numberposts' => -1,
    ));
    
    if (!empty($testimonial_posts)) {
        foreach ($testimonial_posts as $post) {
            $author = get_post_meta($post->ID, '_testimonial_author', true);
            if (empty($author)) {
                $author = get_the_title($post->ID);
            }
            
            $testimonials[] = array(
                'title' => get_the_title($post->ID),
                'text' => get_the_content(null, false, $post->ID),
                'author' => $author,
                'image' => get_the_post_thumbnail_url($post->ID, 'thumbnail') ?: get_template_directory_uri() . '/images/placeholder.png',
            );
        }
    } else {
        // Fallback testimonials if no custom post types exist
        $testimonials = array(
            array(
                'title' => "SEE WHY TEAMS LOVE FUEL-AI",
                'text' => "I was shocked at the impact this had on our sales team. One of our acquisition's guys had been working a lead for months with no success getting him on the calendar. We launched fuelAI and it immediately got the lead scheduled. I met with the client and we were able to close the deal with one phone call! AMAZING!!!!",
                'author' => "Jason Dehle",
                'image' => get_template_directory_uri() . "/images/Jason-Dehle-Testimonial.webp"
            ),
            array(
                'title' => "FUEL.AI CHANGED OUR BUSINESS",
                'text' => "As a solar company our team is constantly moving on to the next opportunity. We struggle to follow up. We needed to consistently reach out to all of our past leads and find those that are still interested. We deployed fuelAI and quickly found 50 deals that were ready to move forward and what's best was our team didn't have to do a thing. fuelAI is awesome!",
                'author' => "Jerry Moen",
                'image' => get_template_directory_uri() . "/images/Jerry-Alta-Energy-Testimonial-Solar.webp"
            ),
            array(
                'title' => "INCREDIBLE ROI",
                'text' => "Our team does a great job closing business, but our struggle has always been getting in contact with our leads. Once we talk to them generally, we do business together. We have seen cases where we had tried to get a hold of a lead over 60 times with no success, and with only 1 day of fuelAI doing the outreach the appointment was scheduled for us. This system is amazing, and the service from the team is top shelf",
                'author' => "Steve Jones",
                'image' => get_template_directory_uri() . "/images/Steve-Jones-and-Jones-Financial-Testimonial-general.webp"
            )
        );
    }
}

// Testimonials Custom Post Type
function fuel_register_testimonials_post_type() {
    $args = array(
        'public' => true,
        'label'  => 'Testimonials',
        'labels' => array(
            'name'               => __('Testimonials', 'fuel-ai'),
            'singular_name'      => __('Testimonial', 'fuel-ai'),
            'add_new'            => __('Add New', 'fuel-ai'),
            'add_new_item'       => __('Add New Testimonial', 'fuel-ai'),
            'edit_item'          => __('Edit Testimonial', 'fuel-ai'),
            'new_item'           => __('New Testimonial', 'fuel-ai'),
            'view_item'          => __('View Testimonial', 'fuel-ai'),
            'search_items'       => __('Search Testimonials', 'fuel-ai'),
            'not_found'          => __('No testimonials found', 'fuel-ai'),
            'not_found_in_trash' => __('No testimonials found in Trash', 'fuel-ai'),
        ),
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-quote',
        'has_archive' => false,
        'rewrite' => array('slug' => 'testimonials'),
    );
    register_post_type('testimonial', $args);
}
add_action('init', 'fuel_register_testimonials_post_type');

// Add custom meta boxes for testimonials
function fuel_testimonial_meta_boxes() {
    add_meta_box(
        'testimonial_author',
        __('Author Information', 'fuel-ai'),
        'fuel_testimonial_author_callback',
        'testimonial',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'fuel_testimonial_meta_boxes');

// Meta box callback function
function fuel_testimonial_author_callback($post) {
    wp_nonce_field('fuel_testimonial_save', 'fuel_testimonial_nonce');
    
    $author = get_post_meta($post->ID, '_testimonial_author', true);
    ?>
    <p>
        <label for="testimonial_author"><?php _e('Author Name:', 'fuel-ai'); ?></label><br>
        <input type="text" id="testimonial_author" name="testimonial_author" value="<?php echo esc_attr($author); ?>" class="widefat">
    </p>
    <?php
}

// Save testimonial meta data
function fuel_save_testimonial_meta($post_id) {
    // Check if our nonce is set
    if (!isset($_POST['fuel_testimonial_nonce'])) {
        return;
    }

    // Verify that the nonce is valid
    if (!wp_verify_nonce($_POST['fuel_testimonial_nonce'], 'fuel_testimonial_save')) {
        return;
    }

    // If this is an autosave, our form has not been submitted, so we don't want to do anything
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check the user's permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Update the author meta field
    if (isset($_POST['testimonial_author'])) {
        update_post_meta(
            $post_id,
            '_testimonial_author',
            sanitize_text_field($_POST['testimonial_author'])
        );
    }
}
add_action('save_post_testimonial', 'fuel_save_testimonial_meta');

// Homepage sections - uses existing sections if the page is set as the front page
function fuel_get_homepage_sections() {
    // Get the ID of the page set as the front page
    $front_page_id = get_option('page_on_front');
    
    // Check if a front page is set and it's not the posts page
    if ($front_page_id && 'page' === get_option('show_on_front')) {
        // Get the content of the front page
        $front_page = get_post($front_page_id);
        
        // Return the content if it exists
        if ($front_page) {
            return apply_filters('the_content', $front_page->post_content);
        }
    }
    
    // Default return empty string if no front page is set
    return '';
}

// Function to get testimonials
function fuel_get_testimonials() {
    $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => -1,
    );
    
    return get_posts($args);
}