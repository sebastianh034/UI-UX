<?php
/**
 * The template for displaying the front page
 */

get_header();
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1 class="hero-title"><?php echo esc_html(get_theme_mod('fuel_hero_title', 'FUEL YOUR SALES WITH AI')); ?></h1>
        
        <div class="hero-main">
            <div class="hero-text">
                <h2 class="hero-heading"><?php echo esc_html(get_theme_mod('fuel_hero_heading', 'BOOK MORE MEETINGS AND CLOSE MORE DEALS. AUTOMATICALLY.')); ?></h2>
                <p class="hero-description">
                    <?php echo esc_html(get_theme_mod('fuel_hero_description', 'AI-powered follow-up and scheduling that converts leads into appointments — so your sales team can focus on selling, not chasing.')); ?>
                </p>
                <a href="<?php echo esc_url(get_theme_mod('fuel_cta_button_link', '#')); ?>" class="cta-button"><?php echo esc_html(get_theme_mod('fuel_cta_button_text', 'BOOK A DEMO TODAY')); ?></a>
            </div>
            
            <?php 
            // Check if YouTube URL is set
            $video_url = get_theme_mod('fuel_hero_video_url', 'https://www.youtube.com/embed/TmUJoSnpd00');
            if ($video_url) : 
            ?>
            <div class="hero-video">
                <iframe
                    width="560" height="315"
                    src="<?php echo esc_url($video_url); ?>"
                    frameborder="0"
                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen
                ></iframe>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Features Section -->
        <div class="features">
            <div class="feature">
                <h3 class="feature-title"><?php echo esc_html(get_theme_mod('fuel_feature1_title', 'FOLLOW-UP MADE EASY')); ?></h3>
                <p class="feature-description">
                    <?php echo esc_html(get_theme_mod('fuel_feature1_description', 'Every lead gets the attention they deserve with perfectly timed, personalized outreach across multiple channels.')); ?>
                </p>
            </div>
            
            <div class="feature">
                <h3 class="feature-title"><?php echo esc_html(get_theme_mod('fuel_feature2_title', 'MORE MEETINGS, LESS HASSLE')); ?></h3>
                <p class="feature-description">
                    <?php echo esc_html(get_theme_mod('fuel_feature2_description', 'fuel.AI boosts lead response rates by automatically sending reminders, managing reminders, and rescheduling when needed.')); ?>
                </p>
            </div>
            
            <div class="feature">
                <h3 class="feature-title"><?php echo esc_html(get_theme_mod('fuel_feature3_title', 'SCALE WITHOUT LIMITS')); ?></h3>
                <p class="feature-description">
                    <?php echo esc_html(get_theme_mod('fuel_feature3_description', 'Grow your business without hiring and administrative overhead, making fuel.AI the ultimate solution for scalable sales automation.')); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section with Graph Image -->
<section class="stats-section">
    <div class="container">
        <h2 class="section-title"><?php echo esc_html(get_theme_mod('fuel_stats_title', 'WHY US?')); ?></h2>
        
        <div class="stats-container">
            <!-- Graph Image Placeholder -->
            <div class="stats-chart-container">
                <div class="graph-placeholder">
                    <!-- Replace this with your actual graph image -->
                    <?php 
                    $stats_image = get_theme_mod('fuel_stats_image');
                    if ($stats_image) :
                    ?>
                        <img src="<?php echo esc_url($stats_image); ?>" alt="Sales statistics graph" class="stats-graph-image">
                    <?php else : ?>
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/chart.svg" alt="Sales statistics graph" class="stats-graph-image">
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right side highlight boxes -->
            <div class="highlight-stats">
                <div class="highlight-box">
                    <span class="highlight-percentage"><?php echo esc_html(get_theme_mod('fuel_stat1_number', '70%')); ?></span>
                    <p class="highlight-description"><?php echo esc_html(get_theme_mod('fuel_stat1_description', 'Of businesses take over 24 hrs to respond to leads')); ?></p>
                </div>
                
                <div class="highlight-box">
                    <span class="highlight-percentage"><?php echo esc_html(get_theme_mod('fuel_stat2_number', '80%')); ?></span>
                    <p class="highlight-description"><?php echo esc_html(get_theme_mod('fuel_stat2_description', 'Of deals go with the vendor that responds first')); ?></p>
                </div>
                
                <div class="highlight-box">
                    <span class="highlight-percentage"><?php echo esc_html(get_theme_mod('fuel_stat3_number', '92%')); ?></span>
                    <p class="highlight-description"><?php echo esc_html(get_theme_mod('fuel_stat3_description', 'Of sales reps only follow-up up to 4 times')); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Service Features Section -->
<section class="service-features">
    <div class="container">
        <div class="service-cards">
            <div class="service-card">
                <h3 class="service-title"><?php echo esc_html(get_theme_mod('fuel_service1_title', 'STUDY YOUR BUSINESS')); ?></h3>
                <p class="service-description">
                    <?php echo esc_html(get_theme_mod('fuel_service1_description', 'We work with you to learn about your processes, your audience, and your business. This is critical in ensuring the AI is structured to speak to your target audience and help you reach your goals.')); ?>
                </p>
            </div>
            
            <div class="service-card">
                <h3 class="service-title"><?php echo esc_html(get_theme_mod('fuel_service2_title', 'BUILD YOUR AI MESSAGING')); ?></h3>
                <p class="service-description">
                    <?php echo esc_html(get_theme_mod('fuel_service2_description', 'We train the AI to organically communicate in a way that represents your brand and your personality. The AI comprehends and responds to messaging through text, email, live chat, and Facebook custom to your business.')); ?>
                </p>
            </div>
            
            <div class="service-card">
                <h3 class="service-title"><?php echo esc_html(get_theme_mod('fuel_service3_title', 'LAUNCH AND LEARN')); ?></h3>
                <p class="service-description">
                    <?php echo esc_html(get_theme_mod('fuel_service3_description', 'The flow is launched and begins to connect to your leads. Working closely with your team, we monitor the AI\'s learning and assist with its training. Our team stays focused on your project to identify short-term wins and increase long-term success.')); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Time Wheel Diagram Section -->
<section class="time-wheel-section">
    <div class="container">
        <!-- Wheel diagram image placeholder -->
        <div class="wheel-diagram-container">
            <?php 
            $wheel_image = get_theme_mod('fuel_wheel_image');
            if ($wheel_image) :
            ?>
                <img src="<?php echo esc_url($wheel_image); ?>" alt="Time allocation diagram" class="wheel-diagram-image">
            <?php else : ?>
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/without.webp" alt="Time allocation diagram" class="wheel-diagram-image">
            <?php endif; ?>
        </div>
        
        <!-- Testimonials Section -->
        <div class="testimonials-container">
            <div class="testimonial-slider">
                <div class="testimonial-navigation">
                    <button class="nav-arrow prev-arrow">
                        <span>←</span>
                    </button>
                    
                    <div class="testimonial-slide active">
                        <!-- Testimonial content will be dynamically inserted here by JavaScript -->
                    </div>
                    
                    <button class="nav-arrow next-arrow">
                        <span>→</span>
                    </button>
                </div>
                
                <div class="testimonial-indicators">
                    <!-- Indicators will be dynamically inserted here by JavaScript -->
                </div>
            </div>

            <div class="testimonial-sidebar">
                <h3 class="sidebar-title"><?php echo esc_html(get_theme_mod('fuel_testimonial_title', 'What they Love about us!')); ?></h3>
                <p class="sidebar-text">
                    <?php echo esc_html(get_theme_mod('fuel_testimonial_description', 'Our clients are passionate about what they do and we are honored that they have trusted us. They have made fuelAI such a huge success. Here\'s some of the kind words they\'ve shared with us.')); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Automation Section -->
<section class="automation-section">
    <div class="container">
        <h2 class="section-title"><?php echo esc_html(get_theme_mod('fuel_automation_title', 'AUTOMATION THAT FEELS LIKE YOUR BEST REP')); ?></h2>
        
        <div class="automation-features">
            <div class="feature-column">
                <div class="feature-box">
                    <h3 class="feature-box-title"><?php echo esc_html(get_theme_mod('fuel_automation1_title', 'AUTHENTIC MESSAGING')); ?></h3>
                    <p class="feature-box-description">
                        <?php echo esc_html(get_theme_mod('fuel_automation1_description', 'Our AI mirrors your brand\'s tone and voice, delivering natural, relational communication that doesn\'t feel robotic.')); ?>
                    </p>
                </div>
            </div>
            
            <div class="feature-column">
                <div class="feature-box">
                    <h3 class="feature-box-title"><?php echo esc_html(get_theme_mod('fuel_automation2_title', 'MULTI-CHANNEL ENGAGEMENT')); ?></h3>
                    <p class="feature-box-description">
                        <?php echo esc_html(get_theme_mod('fuel_automation2_description', 'Reach leads where they are—via email, text, voicemail, live chat, and Facebook Messenger.')); ?>
                    </p>
                </div>
            </div>
            
            <div class="feature-column">
                <div class="feature-box">
                    <h3 class="feature-box-title"><?php echo esc_html(get_theme_mod('fuel_automation3_title', 'INTELLIGENT FOLLOW-UPS')); ?></h3>
                    <p class="feature-box-description">
                        <?php echo esc_html(get_theme_mod('fuel_automation3_description', 'fuel.AI learns from every interaction, ensuring consistent, thoughtful responses that boost lead conversions.')); ?>
                    </p>
                </div>
            </div>
            
            <div class="feature-column">
                <div class="feature-box">
                    <h3 class="feature-box-title"><?php echo esc_html(get_theme_mod('fuel_automation4_title', 'EFFORTLESS SCALABILITY')); ?></h3>
                    <p class="feature-box-description">
                        <?php echo esc_html(get_theme_mod('fuel_automation4_description', 'Seamlessly integrates with your CRM while streamlining workflows, all without losing the personal touch or adding to your team.')); ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="cta-container">
            <a href="<?php echo esc_url(get_theme_mod('fuel_secondary_cta_link', '#')); ?>" class="cta-button secondary-cta"><?php echo esc_html(get_theme_mod('fuel_secondary_cta_text', 'BOOK A DEMO TODAY')); ?></a>
        </div>
    </div>
</section>

<!-- Integration Section -->
<section class="integration-section">
    <div class="container">
        <h2 class="section-title"><?php echo wp_kses_post(get_theme_mod('fuel_integration_title', 'CONNECT WITH<br>THE TOOLS YOU LOVE')); ?></h2>
        
        <div class="globe-container">
            <?php 
            $globe_image = get_theme_mod('fuel_globe_image');
            if ($globe_image) :
            ?>
                <img src="<?php echo esc_url($globe_image); ?>" alt="Globe with integration tool icons" class="globe-img">
            <?php else : ?>
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/globe.png" alt="Globe with integration tool icons" class="globe-img">
            <?php endif; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>