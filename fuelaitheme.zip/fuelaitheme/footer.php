<?php
/**
 * The template for displaying the footer
 */
?>

<!-- Updated Footer with Inline Layout -->
<section class="footer-contact">
    <div class="footer-container">
        <!-- Left side with logo -->
        <div class="footer-logo">
            <div class="logo-inline-container">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/fuel-button-white.png" alt="fuel flame icon" class="footer-flame">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/fuel.AI.png" alt="fuel text logo" class="footer-text">
            </div>
        </div>
        
        <!-- Right side with contact info -->
        <div class="footer-info">
            <div class="footer-contact-text">
                <h3 class="footer-title"><?php echo esc_html__('CONTACT US', 'fuel-ai'); ?></h3>
                <p class="footer-phone"><?php echo esc_html__('PHONE', 'fuel-ai'); ?></p>
                <p class="footer-phone-number"><?php echo esc_html(get_theme_mod('fuel_phone_number', '(435) 375-3509')); ?></p>
                <p class="footer-email"><?php echo esc_html__('EMAIL', 'fuel-ai'); ?></p>
                <p class="footer-email-address"><?php echo esc_html(get_theme_mod('fuel_email_address', 'EXAMPLEEMAIL@GMAIL.COM')); ?></p>
            </div>
            
            <div class="footer-address-social">
                <div class="footer-address">
                    <p><?php echo esc_html(get_theme_mod('fuel_address_line1', '85 N 300 W #C')); ?><br>
                    <?php echo esc_html(get_theme_mod('fuel_address_line2', 'WASHINGTON UTAH')); ?><br>
                    <?php echo esc_html(get_theme_mod('fuel_address_line3', '84790')); ?></p>
                </div>
                
                <!-- Social media icons -->
                <div class="footer-social">
                    <?php if (get_theme_mod('fuel_facebook_url')) : ?>
                    <a href="<?php echo esc_url(get_theme_mod('fuel_facebook_url', '#')); ?>" class="social-icon" target="_blank">
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/facebook.png" alt="Facebook">
                    </a>
                    <?php endif; ?>
                    
                    <?php if (get_theme_mod('fuel_youtube_url')) : ?>
                    <a href="<?php echo esc_url(get_theme_mod('fuel_youtube_url', '#')); ?>" class="social-icon" target="_blank">
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/youtube.webp" alt="YouTube">
                    </a>
                    <?php endif; ?>
                    
                    <?php if (get_theme_mod('fuel_linkedin_url')) : ?>
                    <a href="<?php echo esc_url(get_theme_mod('fuel_linkedin_url', '#')); ?>" class="social-icon" target="_blank">
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/linkedin.png" alt="LinkedIn">
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer navigation -->
<section class="nav-footer">
    <div class="nav-container">
        <?php
        // Display the footer menu
        wp_nav_menu(array(
            'theme_location' => 'footer-menu',
            'menu_class'     => 'footer-nav',
            'container'      => '',
            'fallback_cb'    => false,
            'items_wrap'     => '%3$s', // Remove UL wrapper
            'walker'         => new Fuel_Footer_Nav_Walker(),
        ));
        ?>
    </div>
</section>

<?php wp_footer(); ?>
</body>
</html>